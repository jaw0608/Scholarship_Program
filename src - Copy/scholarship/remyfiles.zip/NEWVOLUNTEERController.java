/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scholarship;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author bflor
 */
public class NEWVOLUNTEERController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML
    Button ADD;
    @FXML
    Button BACK;
    
    @FXML
    ChoiceBox SCHOOLS;
    @FXML
    TextField FIRST;
    @FXML
    TextField LAST;
    @FXML
    TextField MI;
    @FXML
    TextField ADDRESS;
    @FXML
    TextField CITY;
    @FXML
    TextField STATE;
    @FXML
    TextField ZIP;
    @FXML
    TextField GRADYEAR;
    
    public void openHOME (ActionEvent event) throws IOException {
        Stage stage = (Stage) BACK.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("HOME.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    public void addVolunteer (ActionEvent event) throws IOException {
        String first, mi, last, address, city, state, zip, school, year;
        if (hasText(FIRST)) {
            first = FIRST.getText(); System.out.println(first);
            if (hasText(LAST)) {
                last = LAST.getText(); System.out.println(last);
                if (hasText(ADDRESS)) {
                    address=ADDRESS.getText(); System.out.println(address);
                    if (hasText(CITY)) {
                        city = CITY.getText(); System.out.println(city);
                        if (hasText(STATE)) {
                            state = STATE.getText(); System.out.println(state);
                            if (hasText(ZIP)) {
                                zip = ZIP.getText(); System.out.println(zip);
                                if (SCHOOLS.getValue() != null)
                                {
                                    school = (String) SCHOOLS.getValue(); System.out.println(school);
                                    if (hasText(GRADYEAR)) {
                                        year = GRADYEAR.getText(); System.out.println(year);
                                        //SEARCH IF VOLUNTEER EXISTS WITH INFORMATION!
                                        //IF YES: int input = JOptionPane.showOptionDialog(null, "ERROR: Volunteer Already Exists", "ERROR", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
                                        //IF NO: int input = JOptionPane.showOptionDialog(null, "Volunteer added successfully", "Message", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
                                    }
                                }
                                else
                                {
                                    int input = JOptionPane.showOptionDialog(null, "ERROR: Missing Required Information",
                                        "ERROR", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    public boolean hasText(TextField a) {
        if (a.getText() == null || a.getText().equals("")) {
            int input = JOptionPane.showOptionDialog(null, "ERROR: Missing Required Information",
                "ERROR", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, null, null);
            return false;
        }
        else return true;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        SCHOOLS.getItems().addAll("MILLERPLACE", "MOUNTSINAI", "ROCKYPOINT", "SHOREHAM");
    }    
    
}
